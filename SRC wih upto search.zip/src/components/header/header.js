import React, { useState, useEffect, useRef } from "react";
import axios from "axios"; // Import axios for API calls
import "../header/header.css";
import Logo from "../../assets/images/AgriVision (8).png";
import { Link } from "react-router-dom";
import SearchIcon from "@mui/icons-material/Search";
import FavoriteIcon from "@mui/icons-material/Favorite";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { Login } from "@mui/icons-material";
import SelectDrop from "../selectDrop/selectDrop";

const Header = () => {
  const [name, setName] = useState(""); // Added missing state
  const [query, setSearchQuery] = useState("");
  const [result, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [noResults, setNoResults] = useState(false);
  const headerRef = useRef();

  // Function to handle API-based search
  const handleSearch = async () => {
    if (!query.trim()) {
      setSearchResults([]); // Clear results if no query is entered
      setNoResults(false); // Do not show "no results" alert
      return;
    }

    setLoading(true);
    setNoResults(false);

    try {
      const response = await axios.get(
        `https://spring-bootagrivision-production.up.railway.app/api/v1/auth/search/${query}`,
        {
          params: { q: query },
        }
      );
      const data = await response.json();
      setSearchResults(data);

      if (data.length === 0) {
        setNoResults(true); // Show no results only if data is empty
      }
    } catch (error) {
      console.error("Error fetching search results:", error);
      alert("No results found");
    } finally {
      setLoading(false);
    }
  };

  // UseEffect to call search function dynamically whenever `query` changes
  useEffect(() => {
    console.log(name);
    if (query) {
      handleSearch();
    } else {
      setSearchResults([]); // Fixed incorrect state update
      setNoResults(false);
    }
  }, [query]); // Effect depends on `query`

  // Handle input change in search bar
  const handleInputChange = (e) => {
    setSearchQuery(e.target.value); // Only update the query state
  };

  // Handle scroll behavior
  useEffect(() => {
    window.addEventListener("scroll", () => {
      let position = window.pageYOffset;
      if (position > 100) headerRef.current.classList.add("fixed");
      else headerRef.current.classList.remove("fixed");
    });
  }, []);

  return (
    <header className="header" ref={headerRef}>
      <div className="header-container">
        {/* Logo */}
        <div className="header-logo">
          <Link to="/">
            <img src={Logo} alt="Logo" />
          </Link>
        </div>

        {/* Search Bar */}
        <div className="header-search">
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search here for product..."
              value={query}
              onChange={handleInputChange}
            />
            <SearchIcon className="search-icon" />
          </div>

          {/* Show Search Results */}
          {loading && <p>Loading...</p>}
          {noResults && <p>No results found</p>}
          {result.length > 0 && (
            <SelectDrop
              options={result.map((item) => item.productname)} // Adjust based on API response structure
              onOptionSelect={(selected) => setSearchQuery(selected)}
            />
          )}
        </div>

        {/* Navigation Tabs */}
        <div className="header-tabs">
          <Link to="/wishlist" className="header-link">
            <FavoriteIcon className="header-icon" />
            Wishlist
          </Link>
          <Link to="/cart" className="header-link">
            <ShoppingCartIcon className="header-icon" />
            Cart
          </Link>
          <Link to="/login" className="header-link">
            <Login className="header-icon" />
            Log In
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;
